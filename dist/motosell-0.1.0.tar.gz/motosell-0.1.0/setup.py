# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['motosell']

package_data = \
{'': ['*']}

install_requires = \
['Django>=4.1,<5.0',
 'Markdown>=3.4.1,<4.0.0',
 'Pillow>=9.2.0,<10.0.0',
 'django-crispy-forms>=1.14.0,<2.0.0',
 'django-filter>=22.1,<23.0',
 'django-rest-framework>=0.1.0,<0.2.0']

setup_kwargs = {
    'name': 'motosell',
    'version': '0.1.0',
    'description': '',
    'long_description': None,
    'author': 'Sebastian',
    'author_email': 'sebastian.raczylo@gmail.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.9,<4.0',
}


setup(**setup_kwargs)
